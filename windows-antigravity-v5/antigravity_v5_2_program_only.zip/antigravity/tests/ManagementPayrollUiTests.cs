using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;
using CiscoLDTLApp;
class ManagementPayrollUiTests
{
    static void Check(bool ok,string text) { if(!ok) throw new Exception(text); }
    [STAThread] static int Main()
    {
        Application.EnableVisualStyles();
        var w=new WorkshopData { TenPX="Phân xưởng kiểm thử", MaPX="TK", LuongSPQL=1000000 };
        w.ListNhanVien.Clear();
        w.ListNhanVien.Add(new EmployeeRecord { HoTen="Nhân sự giả", LaQuanLy=true, HeSoCoDinh=2, CongSP=26, XepLoai="A", QuanLyTinhMoi=true });
        var preview=typeof(ManagementPayrollForm).GetMethod("Preview",BindingFlags.NonPublic|BindingFlags.Instance);
        using(var f=new ManagementPayrollForm(w))
        {
            f.Show(); Application.DoEvents();
            preview.Invoke(f,new object[]{false}); Application.DoEvents();
            Check(w.ListNhanVien[0].LuongSanPham==0,"Preview must not mutate original");
            preview.Invoke(f,new object[]{true});
            Check(w.ListNhanVien[0].LuongSanPham==1000000 && f.DialogResult==DialogResult.OK,"Apply updates original");
        }
        using(var f=new ManagementPayrollForm(w))
        {
            f.Show(); Application.DoEvents(); f.Close();
            Check(w.ListNhanVien[0].LuongSanPham==1000000,"Close preserves saved state");
        }
        using(var main=new MainForm())
        {
            main.Show(); Application.DoEvents();
            MenuStrip menu=null;
            foreach(Control c in main.Controls) if(c is MenuStrip) menu=(MenuStrip)c;
            Check(menu!=null && menu.Visible && menu.Items.Count==1,"Management entry visible in main form");
            Check(menu.Bounds.Width>500 && menu.Bounds.Height>10,"Management menu has usable size");
            var timer=new Timer { Interval=200 };
            bool found=false;
            timer.Tick+=(s,e)=> {
                foreach(Form form in Application.OpenForms)
                    if(form is ManagementPayrollForm) { found=true; form.Close(); break; }
                timer.Stop();
            };
            timer.Start(); ((ToolStripMenuItem)menu.Items[0]).PerformClick();
            timer.Dispose(); Check(found,"Main form opens management payroll dialog");
            main.Close();
        }
        Console.WriteLine("PASS: WinForms preview, apply, cancel and main menu/dialog smoke test (Linux/Mono)."); return 0;
    }
}
